#include "sys.h"

#undef SUCCESS
#define SUCCESS 0
#undef FAILED
#define FAILED 1
#define ZY_31_SLAVE_ADDRESS 0xC0
#define MODULE_REST 0x20
#define MPU6050_GET_OFFSET 0x21
#define MS5611_GET_OFFSET 0x22
#define MPU_READ 0X30
#define ANGLE_READ 0X32

#define HEIGHT_READ 0X33
#define RATE_READ 0X34
