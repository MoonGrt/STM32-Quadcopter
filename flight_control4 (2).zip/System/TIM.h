#ifndef __TIM_H_
#define __TIM_H_

extern void TIM2_PWM_Config(void);
extern void TIM3_Config(void);

#endif
